


const UuDai = () => {
    return (
        <div>
            <h2>Trang Ưu Đãi</h2>
        </div>
    );
}

export default UuDai;
