import React from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import StaffLayout from "../Layouts/StaffLayout";

// Import các trang Staff
import Movies from "../Pages/Staff/Movies";
import Showtime from "../Pages/Staff/Showtime";
import TheatreReport from "../Pages/Staff/TheatreReport";
import CustomerSupport from "../Pages/Staff/CustomerSupport";
import Profile from "../Pages/Staff/Profile";
import Promotion from "../Pages/Staff/Promotion";
import TopPhim from "../Pages/Staff/TopPhim";

const StaffRoutes = () => {
    return (
        <StaffLayout>
            <Switch>
                <Route path="/staff/movies" component={Movies} />
                <Route path="/staff/showtimes" component={Showtime} />
                <Route path="/staff/reports" component={TheatreReport} />
                <Route path="/staff/support" component={CustomerSupport} />
                <Route path="/staff/profile" component={Profile} />
                <Route path="/staff/promotions" component={Promotion} />

                <Route path="/staff/topmovies" component={TopPhim} />

                {/* Mặc định chuyển hướng */}
                <Redirect to="/staff/movies" />
            </Switch>
        </StaffLayout>
    );
};

export default StaffRoutes;
