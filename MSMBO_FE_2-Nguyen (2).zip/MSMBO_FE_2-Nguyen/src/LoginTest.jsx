import React from "react";

const LoginTest = () => {
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("✅ Form đã submit!");
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" placeholder="Username" />
            <button type="submit">Đăng nhập</button>
        </form>
    );
};

export default LoginTest;
