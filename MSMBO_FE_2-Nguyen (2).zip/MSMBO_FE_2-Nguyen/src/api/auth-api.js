// src/api/auth-api.js
import axios from "axios";

const BASE_URL = "http://localhost:8080/api/auth"; // đổi theo backend của bạn

export const authApi = {
    login: async (userName, password) => {
        try {
            const response = await axios.post(`${BASE_URL}/login`, {
                userName,
                password,
            });
            return response.data;
        } catch (error) {
            throw error.response?.data || { message: "Đăng nhập thất bại" };
        }
    },
};
