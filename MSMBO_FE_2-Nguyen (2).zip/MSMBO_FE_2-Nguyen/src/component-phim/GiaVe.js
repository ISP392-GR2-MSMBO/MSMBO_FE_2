

const GiaVe = () => {
    return (
        <div>
            <h2>Trang Giá Vé</h2>
        </div>
    );
}

export default GiaVe;
