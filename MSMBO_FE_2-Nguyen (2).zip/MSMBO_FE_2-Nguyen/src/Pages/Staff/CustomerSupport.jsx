import React, { useEffect, useState } from "react";
import axios from "axios";
import "./CustomerSupport.css";

const CustomerSupport = () => {
    const [reports, setReports] = useState([]);
    const [selectedReport, setSelectedReport] = useState(null);
    const [filterStatus, setFilterStatus] = useState("PENDING");

    const fetchReports = async () => {
        try {
            const res = await axios.get("http://localhost:8080/api/reports/queue", {
                params: { type: "CUSTOMER_FEEDBACK" }
            });
            setReports(res.data);
        } catch (error) {
            console.error("❌ Lỗi lấy danh sách report:", error);
        }
    };

    const updateStatus = async (reportId, newStatus) => {
        try {
            await axios.patch(`http://localhost:8080/api/reports/${reportId}/status`, {
                status: newStatus
            });
            fetchReports();
        } catch (error) {
            console.error("❌ Lỗi cập nhật trạng thái:", error);
        }
    };

    useEffect(() => { fetchReports(); }, []);

    const filteredReports = reports.filter(r => r.status === filterStatus);

    return (
        <div className="staff-page">
            <h2>💬 Hỗ trợ khách hàng</h2>
            <p className="subtext">Xử lý các phản hồi, góp ý và vấn đề từ khách hàng.</p>

            {/* ✅ TAB STATUS */}
            <div className="status-tabs">
                {["PENDING", "IN_PROGRESS", "RESOLVED", "REJECTED"].map(s => (
                    <button
                        key={s}
                        className={`status-tab ${filterStatus === s ? "active" : ""}`}
                        onClick={() => setFilterStatus(s)}
                    >
                        {s.replace("_", " ")}
                    </button>
                ))}
            </div>

            {/* ✅ TABLE */}
            <table className="report-table">
                <thead>
                    <tr>
                        <th>Mô tả</th>
                        <th>Ngày gửi</th>
                        <th>Trạng thái</th>
                        <th>Hành động</th>
                    </tr>
                </thead>

                <tbody>
                    {filteredReports.map((r) => (
                        <tr key={r.reportID}>
                            <td className="desc-click" onClick={() => setSelectedReport(r)}>
                                {r.description?.length > 40
                                    ? r.description.slice(0, 40) + "..."
                                    : r.description}
                            </td>

                            <td>{new Date(r.createdDate).toLocaleString()}</td>
                            <td className={`status-${r.status.toLowerCase()}`}>{r.status}</td>

                            <td>
                                {r.status === "PENDING" && (
                                    <>
                                        <button className="btn in-progress" onClick={() => updateStatus(r.reportID, "IN_PROGRESS")}>
                                            ⏳ Nhận xử lý
                                        </button>
                                        <button className="btn reject" onClick={() => updateStatus(r.reportID, "REJECTED")}>
                                            ❌ Từ chối
                                        </button>
                                    </>
                                )}

                                {r.status === "IN_PROGRESS" && (
                                    <button className="btn resolved" onClick={() => updateStatus(r.reportID, "RESOLVED")}>
                                        ✅ Hoàn thành
                                    </button>
                                )}

                                {r.status === "RESOLVED" && <span className="done-text">✔ Đã hoàn thành</span>}
                                {r.status === "REJECTED" && <span className="reject-text">❌ Đã từ chối</span>}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            {/* ✅ POPUP */}
            {selectedReport && (
                <div className="modal-backdrop" onClick={() => setSelectedReport(null)}>
                    <div className="modal" onClick={(e) => e.stopPropagation()}>
                        <h3>📝 Chi tiết báo cáo</h3>
                        <p className="modal-desc">{selectedReport.description}</p>
                        <button className="close-btn" onClick={() => setSelectedReport(null)}>Đóng</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CustomerSupport;
