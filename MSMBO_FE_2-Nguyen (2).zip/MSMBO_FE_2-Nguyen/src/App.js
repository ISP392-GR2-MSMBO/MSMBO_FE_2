import Navbar from './Navbar';
import Home from './Home';
import { BrowserRouter as Router, Route, Switch, useLocation } from 'react-router-dom';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import StaffRoutes from "./Routes/StaffRoutes";
import AdminRoutes from "./Routes/AdminRoutes"; // ✅ thêm dòng này

// Các trang phía người dùng
import Phim from './component-phim/Phim';
import PhimSapChieu from './component-phim/PhimSapChieu';
import Login from './Login';
import Register from './component-phim/Register';
import LichChieu from './component-phim/LichChieu';
import GiaVe from './component-phim/GiaVe';
import UuDai from './component-phim/UuDai';
import LienHe from './component-phim/LienHe';
import Footer from './Footer';
import LoginTest from './LoginTest';
import MovieDetail from "./component-phim/MovieDetail";




function AppContent() {
  const location = useLocation();

  // ✅ Nếu là trang Staff (bắt đầu bằng /staff) thì ẩn Navbar + Footer
  const isStaffPage = location.pathname.startsWith("/staff");
  const isAdminPage = location.pathname.startsWith("/admin");
  const hideLayout = isStaffPage || isAdminPage; // ✅ Gộp chung điều kiện
  return (
    <div className="App">
      {!hideLayout && <Navbar />} {/* Ẩn nếu là admin hoặc staff */}

      <div className="content">
        <Switch>
          {/* ✅ Trang chính cho người dùng */}
          <Route exact path="/" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/phim" component={Phim} />
          <Route path="/phim-sap-chieu" component={PhimSapChieu} />
          <Route path="/lich-chieu" component={LichChieu} />
          <Route path="/gia-ve" component={GiaVe} />
          <Route path="/uu-dai" component={UuDai} />
          <Route path="/lien-he" component={LienHe} />
          <Route path="/movies/:id" component={MovieDetail} />
          <Route path="/test" component={LoginTest} />

          {/* ✅ Trang Staff riêng (Layout riêng, không dùng Navbar/Footer App) */}
          <Route path="/staff" component={StaffRoutes} />

          {/* --- Route riêng cho Admin --- */}
          <Route path="/admin" component={AdminRoutes} /> {/* ✅ thêm dòng này */}
        </Switch>

      </div>

      {!isStaffPage && <Footer />}
    </div>
  );
}


function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
