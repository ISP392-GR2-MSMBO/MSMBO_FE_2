import React, { useState, useEffect } from "react";
import "./SProfile.css";
import { userApi } from "../../api/user-api";

const Profile = () => {
    const [user, setUser] = useState(null);
    const [errorMessage, setErrorMessage] = useState("");

    const [formData, setFormData] = useState({
        fullName: "",
        email: "",
        phone: "",
        roleID: "",
        userName: "",
    });
    const [isEditing, setIsEditing] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let storedAuth = null;
        try {
            storedAuth = JSON.parse(localStorage.getItem("user"));
        } catch (e) {
            console.warn("⚠️ Lỗi đọc localStorage:", e);
        }

        const userName = storedAuth?.userName;
        if (userName) {
            const fetchUser = async () => {
                try {
                    // ✅ Lấy thông tin theo userName
                    const res = await userApi.getUserByUsername(userName);
                    const userData = Array.isArray(res) ? res[0] : res;
                    if (!userData) throw new Error("Không tìm thấy thông tin người dùng!");

                    setUser(userData);
                    setFormData({
                        fullName: userData.fullName ?? "",
                        email: userData.email ?? "",
                        phone: userData.phone ?? "",
                        roleID: userData.roleID ?? "",
                        userName: userData.userName ?? "",
                    });
                } catch (err) {
                    console.error("❌ Lỗi khi tải thông tin người dùng:", err);
                    setUser(storedAuth);
                    setFormData({
                        fullName: storedAuth?.fullName ?? "",
                        email: storedAuth?.email ?? "",
                        phone: storedAuth?.phone ?? "",
                        roleID: storedAuth?.roleID ?? "",
                        userName: storedAuth?.userName ?? "",
                    });
                } finally {
                    setLoading(false);
                }
            };
            fetchUser();
        } else {
            console.warn("⚠️ Không tìm thấy userName trong localStorage!");
            setLoading(false);
        }
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleUpdate = async (e) => {
        e.preventDefault();
        setErrorMessage(""); // Xoá lỗi cũ

        try {
            const userID = user?.userID;
            if (!userID) {
                setErrorMessage("Không tìm thấy userID!");
                return;
            }

            // ✅ Kiểm tra số điện thoại phải là **10 số**
            const phoneRegex = /^[0-9]{10}$/;
            if (formData.phone && !phoneRegex.test(formData.phone)) {
                setErrorMessage("📱 Số điện thoại phải gồm đúng 10 chữ số!");
                return;
            }

            const updateBody = {
                fullName: formData.fullName.trim(),
                email: formData.email.trim(),
                phone: formData.phone.trim(),
            };

            const updatedUser = await userApi.updateUser(userID, updateBody);

            setUser(updatedUser);
            localStorage.setItem("user", JSON.stringify(updatedUser));
            setIsEditing(false);

        } catch (error) {
            console.error("❌ Lỗi khi cập nhật:", error);
            setErrorMessage("Không thể cập nhật thông tin!");
        }
    };
    const handleCancel = () => {
        setErrorMessage(""); // Xóa lỗi cũ nếu có
        setFormData({
            fullName: user.fullName ?? "",
            email: user.email ?? "",
            phone: user.phone ?? "",
            roleID: user.roleID ?? "",
            userName: user.userName ?? "",
        });
        setIsEditing(false);
    };



    if (loading)
        return <div className="profile-container">⏳ Đang tải thông tin người dùng...</div>;

    if (!user)
        return <div className="profile-container">❌ Không có thông tin người dùng!</div>;

    return (
        <div className="profile-container">
            <h2>👤 Thông tin cá nhân</h2>

            {!isEditing ? (
                <div className="profile-view">
                    <p><strong>Tên đăng nhập:</strong> {formData.userName}</p>
                    <p><strong>Họ và tên:</strong> {formData.fullName}</p>
                    <p><strong>Email:</strong> {formData.email}</p>
                    <p><strong>Số điện thoại:</strong> {formData.phone}</p>
                    <p><strong>Vai trò:</strong> {formData.roleID}</p>
                    <button onClick={() => setIsEditing(true)} className="btn-edit">
                        ✏️ Chỉnh sửa
                    </button>
                </div>
            ) : (
                <form className="profile-form" onSubmit={handleUpdate}>
                    <label>Họ và tên:</label>
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                    />

                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />

                    <label>Số điện thoại:</label>
                    <input
                        type="text"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                    />
                    {errorMessage && (
                        <div className="error-box">
                            {errorMessage}
                        </div>
                    )}

                    <div className="btn-group">
                        <button type="submit" className="btn-save">💾 Lưu</button>
                        <button
                            type="button"
                            className="btn-cancel"
                            onClick={handleCancel}
                        >
                            ❌ Hủy
                        </button>

                    </div>
                </form>
            )}
        </div>
    );
};

export default Profile;
