import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Promotion.css";

const API_BASE = "http://localhost:8080/api";

export default function PromotionPage() {
    const [seatTypes, setSeatTypes] = useState([]);
    const [selectedSeatTypeIds, setSelectedSeatTypeIds] = useState([]);
    const [promotions, setPromotions] = useState([]);
    const [loading, setLoading] = useState(false);

    const [form, setForm] = useState({
        name: "",
        description: "",
        discountValue: 0,
        startDate: "",
        endDate: "",
        discountType: "percentage",
    });

    const getAuthHeader = () => {
        const token = localStorage.getItem("token");
        return token ? { Authorization: `Bearer ${token}` } : {};
    };

    const mapDiscountType = (type) => {
        if (type === "percentage") return "PERCENT";
        if (type === "fixed_amount") return "AMOUNT";
        return type;
    };

    const loadSeatTypes = () => {
        axios.get(`${API_BASE}/seat/seat-type/all`, { headers: getAuthHeader() })
            .then(res => setSeatTypes(res.data))
            .catch(() => alert("⚠️ Lỗi tải loại ghế"));
    };

    const loadPromotions = () => {
        axios.get(`${API_BASE}/admin/promotions`, { headers: getAuthHeader() })
            .then(res => setPromotions(res.data))
            .catch(() => alert("⚠️ Lỗi tải danh sách khuyến mãi"));
    };

    useEffect(() => {
        loadSeatTypes();
        loadPromotions();
    }, []);

    const toggleSeatType = (id) => {
        setSelectedSeatTypeIds(prev =>
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const handleSubmit = async () => {
        if (!form.name) return alert("Nhập tên khuyến mãi");
        if (!form.startDate || !form.endDate) return alert("Chọn ngày");
        if (selectedSeatTypeIds.length === 0) return alert("Chọn ít nhất 1 loại ghế");

        setLoading(true);
        try {
            await axios.post(
                `${API_BASE}/admin/promotions`,
                {
                    name: form.name,
                    description: form.description,
                    startDate: form.startDate,
                    endDate: form.endDate,
                    discountType: mapDiscountType(form.discountType), // PERCENT / AMOUNT
                    discountValue: form.discountValue,
                    seatTypeIds: selectedSeatTypeIds // ✅ Gửi seat type luôn
                },
                { headers: getAuthHeader() }
            );

            alert("✅ Tạo khuyến mãi thành công!");
            loadPromotions(); // refresh danh sách

            // reset form
            setForm({
                name: "",
                description: "",
                discountValue: 0,
                startDate: "",
                endDate: "",
                discountType: "percentage",
            });
            setSelectedSeatTypeIds([]);

        } catch (err) {
            const msg = err.response?.data?.message || "Lỗi tạo khuyến mãi";
            alert("❌ " + msg);
        } finally {
            setLoading(false);
        }
    };


    const toggleStatus = async (promotion) => {
        try {
            await axios.patch(
                `${API_BASE}/admin/promotions/${promotion.promotionID}/status`,
                { isActive: !promotion.active },  // <--- SỬA Ở ĐÂY
                { headers: getAuthHeader() }
            );

            loadPromotions();
        } catch (err) {
            console.error(err);
            alert("⚠️ Lỗi khi đổi trạng thái khuyến mãi");
        }
    };


    return (
        <div className="create-promo">
            <h2>🎟️ Quản lý Khuyến Mãi</h2>

            {/* FORM TẠO */}
            <div className="promo-form">
                <input className="input" placeholder="Tên khuyến mãi"
                    value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />

                <input className="input" placeholder="Mô tả"
                    value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

                <select className="input" value={form.discountType}
                    onChange={(e) => setForm({ ...form, discountType: e.target.value })}>
                    <option value="percentage">Giảm %</option>
                    <option value="fixed_amount">Giảm số tiền</option>
                </select>

                <input className="input" type="number" min="0" placeholder="Giá trị giảm"
                    value={form.discountValue} onChange={(e) => setForm({ ...form, discountValue: Number(e.target.value) })} />

                <input className="input" type="date"
                    value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />

                <input className="input" type="date"
                    value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />

                <h4>Áp dụng cho loại ghế:</h4>
                <div className="seat-list">
                    {seatTypes.map(s => (
                        <label key={s.seatTypeID} className="seat-item">
                            <input type="checkbox"
                                checked={selectedSeatTypeIds.includes(s.seatTypeID)}
                                onChange={() => toggleSeatType(s.seatTypeID)} />
                            {s.name} — {Number(s.basePrice).toLocaleString()}đ
                        </label>
                    ))}
                </div>

                <button className="btn btn-primary" disabled={loading} onClick={handleSubmit}>
                    {loading ? "Đang xử lý..." : "Tạo khuyến mãi"}
                </button>
            </div>

            <hr style={{ margin: "20px 0" }} />

            {/* LIST */}
            <h3>📋 Danh sách khuyến mãi</h3>

            <table>
                <thead>
                    <tr>
                        <th>Tên</th>
                        <th>Giảm</th>
                        <th>Thời gian</th>
                        <th>Loại ghế áp dụng</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    {promotions.map(p => (
                        <tr key={p.promotionID}>
                            <td>{p.name}</td>
                            <td>{p.discountValue} ({p.discountType})</td>
                            <td>{p.startDate} → {p.endDate}</td>
                            <td>{p.applicableSeatTypes?.map(s => s.name).join(", ") || "—"}</td>
                            <td>
                                <button
                                    className={p.active ? "btn-off" : "btn-on"}
                                    onClick={() => toggleStatus(p)}
                                >
                                    {p.active ? "Tắt" : "Bật"}
                                </button>

                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}
