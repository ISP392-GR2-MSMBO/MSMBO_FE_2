import React, { useState } from "react";
import axios from "axios";
import { useHistory } from "react-router-dom";
import "./index.css";

const Login = () => {
    const [userName, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const history = useHistory();

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const res = await axios.post("http://localhost:8080/api/auth/login", {
                userName,
                password,
            });

            console.log("📩 Response từ backend:", res.data);

            if (res.data && res.data.token) {
                // ✅ Lưu token riêng
                localStorage.setItem("token", res.data.token);

                // ✅ Lưu thông tin người dùng
                const userData = {
                    userID: res.data.userID,
                    userName: res.data.userName,
                    roleID: res.data.roleID,
                };
                localStorage.setItem("user", JSON.stringify(userData));

                alert("✅ Đăng nhập thành công!");

                // ✅ Điều hướng theo vai trò
                if (res.data.roleID === "ST") {
                    history.push("/staff/movies");
                } else if (res.data.roleID === "AD") {
                    history.push("/admin/users");
                } else {
                    history.push("/");
                }
            } else {
                alert("❌ Phản hồi không hợp lệ từ server!");
            }
        } catch (err) {
            console.error("🚨 Lỗi đăng nhập:", err);
            if (err.response)
                console.log("❌ Server trả về:", err.response.data);
            alert("Sai tài khoản hoặc mật khẩu!");
        }
    };

    return (
        <div className="auth-container">
            <h2>Đăng nhập</h2>
            <form className="auth-form" onSubmit={handleLogin}>
                <input
                    type="text"
                    placeholder="Tên đăng nhập"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    required
                />
                <br />
                <input
                    type="password"
                    placeholder="Mật khẩu"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <br />
                <button type="submit">Đăng nhập</button>
            </form>

            <p className="auth-link">
                Chưa có tài khoản? <a href="/register">Đăng ký ngay</a>
            </p>
        </div>
    );
};

export default Login;
